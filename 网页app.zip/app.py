from flask import Flask, render_template, request, redirect, url_for
import json

app = Flask(__name__)

# 用于存储订单数据的文件名
DATA_FILE = 'orders.json'

# 加载订单数据
def load_orders():
    try:
        with open(DATA_FILE, 'r') as file:
            return json.load(file)
    except (FileNotFoundError, json.JSONDecodeError):
        return []

# 保存订单数据
def save_orders(orders):
    with open(DATA_FILE, 'w') as file:
        json.dump(orders, file, ensure_ascii=False, indent=4)

# 加载订单数据
orders = load_orders()

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        # 从表单中获取数据
        order = {
            'order_id': request.form.get('order_id'),
            'task_type': request.form.get('task_type'),
            'start_date': request.form.get('start_date'),
            'keyword': request.form.get('keyword'),
            'task_amount': request.form.get('task_amount'),
            'execution_count': request.form.get('execution_count'),
            'task_status': request.form.get('task_status')
        }
        # 将新订单添加到订单列表
        orders.append(order)
        save_orders(orders)
        return redirect(url_for('index'))

    # 渲染页面，并传递订单数据
    return render_template('index.html', orders=orders)

@app.route('/delete/<int:index>', methods=['POST'])
def delete_order(index):
    if 0 <= index < len(orders):
        del orders[index]
        save_orders(orders)
    return redirect(url_for('index'))

@app.route('/update/<int:index>', methods=['GET', 'POST'])
def update_order(index):
    if request.method == 'POST':
        if 0 <= index < len(orders):
            # 更新订单数据
            orders[index] = {
                'order_id': request.form.get('order_id'),
                'task_type': request.form.get('task_type'),
                'start_date': request.form.get('start_date'),
                'keyword': request.form.get('keyword'),
                'task_amount': request.form.get('task_amount'),
                'execution_count': request.form.get('execution_count'),
                'task_status': request.form.get('task_status')
            }
            save_orders(orders)
        return redirect(url_for('index'))
    
    # 渲染修改表单页面
    return render_template('update.html', order=orders[index], index=index)

if __name__ == '__main__':
    app.run(debug=True)
