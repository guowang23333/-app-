import os
import shutil
import tkinter as tk
from tkinter import ttk, filedialog, simpledialog, messagebox
import random
import string

class FileManagerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("文件夹精灵2024")
        self.create_widgets()
        self.create_status_bar()

    def create_widgets(self):
        frame = tk.Frame(self.root)
        frame.pack(pady=10)

        self.directory = tk.StringVar()

        dir_label = tk.Label(frame, text="目录路径:")
        dir_label.grid(row=0, column=0, padx=5, pady=5)
        dir_entry = tk.Entry(frame, textvariable=self.directory, width=50)
        dir_entry.grid(row=0, column=1, padx=5, pady=5)
        browse_button = tk.Button(frame, text="浏览", command=self.browse_directory)
        browse_button.grid(row=0, column=2, padx=5, pady=5)

        self.create_menu(frame)
        self.create_tool_buttons(frame)

        # 创建Treeview控件
        columns = ("名称", "预览", "状态")
        self.tree = ttk.Treeview(self.root, columns=columns, show="headings")
        self.tree.heading("名称", text="名称")
        self.tree.heading("预览", text="预览")
        self.tree.heading("状态", text="状态")

        self.tree.column("名称", width=200)
        self.tree.column("预览", width=200)
        self.tree.column("状态", width=200)

        self.tree.pack(pady=10)

        # 更新文件列表
        self.list_files()

    def create_menu(self, frame):
        menu_label = tk.Label(frame, text="右键菜单操作:")
        menu_label.grid(row=1, column=0, padx=5, pady=5)
        self.context_menu = tk.Menu(self.root, tearoff=0)
        self.context_menu.add_command(label="编辑（手动改名）", command=self.manual_rename)

        self.context_menu.add_separator()
        self.context_menu.add_command(label="移除（从列表中移除）", command=self.remove_from_list)
        self.context_menu.add_command(label="删除（从电脑中删除）", command=self.delete_from_computer)
        self.context_menu.add_command(label="清空列表", command=self.clear_list)
        self.context_menu.add_separator()
        self.context_menu.add_command(label="名称重置", command=self.reset_name)
        self.context_menu.add_command(label="重名检查", command=self.check_duplicate_names)
        self.context_menu.add_command(label="执行修改", command=self.execute_changes)
        self.context_menu.add_separator()
        self.context_menu.add_command(label="导入名称", command=self.import_names)
        self.context_menu.add_command(label="导出名称", command=self.export_names)
        self.context_menu.add_separator()
        self.context_menu.add_command(label="复制", command=self.copy_item)
        self.context_menu.add_command(label="打开", command=self.open_item)
        self.context_menu.add_command(label="打开路径", command=self.open_path)

        self.root.bind("<Button-3>", self.show_context_menu)

    def create_tool_buttons(self, frame):
        tool_label = tk.Label(frame, text="工具按钮操作:")
        tool_label.grid(row=2, column=0, padx=5, pady=5)

        tool_frame = tk.Frame(frame)
        tool_frame.grid(row=3, column=0, columnspan=3, padx=5, pady=5)

        buttons = [
            ("文件搜索", self.search_files),
            ("替换字符", self.replace_characters),
            ("删除字符", self.delete_characters),
            ("插入字符", self.insert_characters),
            ("随机命名", self.random_rename),
            ("前缀后缀", self.prefix_suffix),
            ("数字编号", self.numbering),
            ("大写小写", self.change_case),
            ("扩展名称", self.extend_name),
            ("随机排序", self.random_sort),
            ("数字排序", self.number_sort),
            ("疯狂乱序", self.crazy_shuffle),
            ("清空列表", self.clear_list),
            ("重名检查", self.check_duplicate_names),
            ("执行修改", self.execute_changes),
        ]

        for text, command in buttons:
            button = tk.Button(tool_frame, text=text, command=command)
            button.pack(side=tk.LEFT, padx=5, pady=5)

    def create_status_bar(self):
        status_frame = tk.Frame(self.root)
        status_frame.pack(side=tk.BOTTOM, fill=tk.X)

        self.status_label = tk.Label(status_frame, text="状态栏", bd=1, relief=tk.SUNKEN, anchor=tk.W)
        self.status_label.pack(fill=tk.X)

    def update_status_bar(self, message):
        self.status_label.config(text=message)

    def browse_directory(self):
        directory = filedialog.askdirectory()
        if directory:
            self.directory.set(directory)
            self.update_status_bar(f"当前目录: {directory}")
            self.list_files()

    def show_context_menu(self, event):
        try:
            self.context_menu.tk_popup(event.x_root, event.y_root)
        finally:
            self.context_menu.grab_release()

    def random_string(self, length=8):
        return ''.join(random.choices(string.ascii_letters + string.digits, k=length))

    def manual_rename(self):
        directory = self.directory.get()
        if not os.path.isdir(directory):
            messagebox.showerror("错误", "目录无效")
            return
        file = filedialog.askopenfilename(initialdir=directory, title="选择要重命名的文件")
        if file:
            new_name = simpledialog.askstring("输入新名称", "请输入新的文件名（不含扩展名）:")
            if new_name:
                base, ext = os.path.splitext(file)
                new_file = os.path.join(os.path.dirname(file), new_name + ext)
                os.rename(file, new_file)
                messagebox.showinfo("完成", f"文件重命名为: {new_file}")
                self.update_status_bar(f"文件已重命名为: {new_file}")
                self.list_files()

    def remove_from_list(self):
        selected_items = self.tree.selection()
        for item in selected_items:
            self.tree.delete(item)
        self.update_status_bar("已从列表中移除。")

    def delete_from_computer(self):
        directory = self.directory.get()
        if not os.path.isdir(directory):
            messagebox.showerror("错误", "目录无效")
            return
        selected_items = self.tree.selection()
        for item in selected_items:
            file_name = self.tree.item(item, 'values')[0]
            file_path = os.path.join(directory, file_name)
            os.remove(file_path)
            self.tree.delete(item)
        messagebox.showinfo("完成", "文件已删除")
        self.update_status_bar(f"已删除 {len(selected_items)} 个文件")

    def clear_list(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        self.update_status_bar("列表已清空")

    def reset_name(self):
        directory = self.directory.get()
        if not os.path.isdir(directory):
            messagebox.showerror("错误", "目录无效")
            return
        for item in self.tree.get_children():
            file_name = self.tree.item(item, 'values')[0]
            file_path = os.path.join(directory, file_name)
            base, ext = os.path.splitext(file_name)
            new_name = base.lower() + ext
            new_file_path = os.path.join(directory, new_name)
            os.rename(file_path, new_file_path)
            self.tree.item(item, values=(new_name, new_name, "未处理"))
        messagebox.showinfo("完成", "文件名已重置为小写")
        self.update_status_bar("文件名已重置为小写")

    def check_duplicate_names(self):
        directory = self.directory.get()
        if not os.path.isdir(directory):
            messagebox.showerror("错误", "目录无效")
            return
        files = os.listdir(directory)
        duplicates = [file for file in files if files.count(file) > 1]
        if duplicates:
            self.text_area.insert(tk.END, "重复文件:\n" + "\n".join(duplicates))
            self.update_status_bar(f"发现 {len(duplicates)} 个重复文件")
        else:
            messagebox.showinfo("检查", "没有发现重复文件名。")
            self.update_status_bar("没有发现重复文件名")

    def execute_changes(self):
        messagebox.showinfo("执行修改", "已执行所有修改。")
        self.update_status_bar("已执行所有修改")

    def import_names(self):
        messagebox.showinfo("导入名称", "此功能尚未实现。")
        self.update_status_bar("导入名称功能尚未实现")

    def export_names(self):
        messagebox.showinfo("导出名称", "此功能尚未实现。")
        self.update_status_bar("导出名称功能尚未实现")

    def copy_item(self):
        directory = self.directory.get()
        if not os.path.isdir(directory):
            messagebox.showerror("错误", "目录无效")
            return
        selected_items = self.tree.selection()
        for item in selected_items:
            file_name = self.tree.item(item, 'values')[0]
            file_path = os.path.join(directory, file_name)
            dest = filedialog.askdirectory(title="选择目标文件夹")
            if dest:
                shutil.copy(file_path, dest)
        messagebox.showinfo("完成", "文件已复制")
        self.update_status_bar("文件已复制")
        self.list_files()

    def open_item(self):
        directory = self.directory.get()
        if not os.path.isdir(directory):
            messagebox.showerror("错误", "目录无效")
            return
        file = filedialog.askopenfilename(initialdir=directory, title="选择要打开的文件")
        if file:
            os.startfile(file)
            self.update_status_bar(f"打开文件: {file}")

    def open_path(self):
        directory = self.directory.get()
        if not os.path.isdir(directory):
            messagebox.showerror("错误", "目录无效")
            return
        os.startfile(directory)
        self.update_status_bar(f"打开目录: {directory}")

    def add_files(self):
        files = filedialog.askopenfilenames(title="选择文件")
        for file in files:
            self.text_area.insert(tk.END, file + "\n")
        self.update_status_bar(f"添加了 {len(files)} 个文件")

    def select_directory(self):
        directory = filedialog.askdirectory(title="选择目录")
        if directory:
            self.text_area.insert(tk.END, directory + "\n")
            self.update_status_bar(f"选择了目录: {directory}")

    def nested_directory(self):
        messagebox.showinfo("目录嵌套", "此功能尚未实现。")
        self.update_status_bar("目录嵌套功能尚未实现")

    def filter_files(self):
        messagebox.showinfo("文件过滤", "此功能尚未实现。")
        self.update_status_bar("文件过滤功能尚未实现")

    def search_files(self):
        query = simpledialog.askstring("文件搜索", "请输入搜索关键字:")
        if query:
            directory = self.directory.get()
            if not os.path.isdir(directory):
                messagebox.showerror("错误", "目录无效")
                return
            results = []
            for root, dirs, files in os.walk(directory):
                for file in files:
                    if query.lower() in file.lower():
                        results.append(os.path.join(root, file))
            if results:
                for result in results:
                    self.tree.insert("", tk.END, values=(os.path.basename(result), result, "未处理"))
                self.update_status_bar(f"找到 {len(results)} 个匹配文件")
            else:
                messagebox.showinfo("搜索", "未找到匹配的文件。")
                self.update_status_bar("未找到匹配的文件")

    def replace_characters(self):
        old_char = simpledialog.askstring("替换字符", "请输入要替换的字符:")
        new_char = simpledialog.askstring("替换字符", "请输入新的字符:")
        if old_char and new_char:
            directory = self.directory.get()
            if not os.path.isdir(directory):
                messagebox.showerror("错误", "目录无效")
                return
            for item in self.tree.get_children():
                file_name = self.tree.item(item, 'values')[0]
                file_path = os.path.join(directory, file_name)
                new_name = file_name.replace(old_char, new_char)
                new_file_path = os.path.join(directory, new_name)
                os.rename(file_path, new_file_path)
                self.tree.item(item, values=(new_name, new_name, "未处理"))
            messagebox.showinfo("完成", "字符替换完成")
            self.update_status_bar("字符替换完成")

    def delete_characters(self):
        char_to_delete = simpledialog.askstring("删除字符", "请输入要删除的字符:")
        if char_to_delete:
            directory = self.directory.get()
            if not os.path.isdir(directory):
                messagebox.showerror("错误", "目录无效")
                return
            for item in self.tree.get_children():
                file_name = self.tree.item(item, 'values')[0]
                file_path = os.path.join(directory, file_name)
                new_name = file_name.replace(char_to_delete, "")
                new_file_path = os.path.join(directory, new_name)
                os.rename(file_path, new_file_path)
                self.tree.item(item, values=(new_name, new_name, "未处理"))
            messagebox.showinfo("完成", "字符删除完成")
            self.update_status_bar("字符删除完成")

    def insert_characters(self):
        insert_pos = simpledialog.askinteger("插入字符", "请输入要插入字符的位置（从0开始）:")
        char_to_insert = simpledialog.askstring("插入字符", "请输入要插入的字符:")
        if insert_pos is not None and char_to_insert:
            directory = self.directory.get()
            if not os.path.isdir(directory):
                messagebox.showerror("错误", "目录无效")
                return
            for item in self.tree.get_children():
                file_name = self.tree.item(item, 'values')[0]
                file_path = os.path.join(directory, file_name)
                new_name = file_name[:insert_pos] + char_to_insert + file_name[insert_pos:]
                new_file_path = os.path.join(directory, new_name)
                os.rename(file_path, new_file_path)
                self.tree.item(item, values=(new_name, new_name, "未处理"))
            messagebox.showinfo("完成", "字符插入完成")
            self.update_status_bar("字符插入完成")

    def random_rename(self):
        directory = self.directory.get()
        if not os.path.isdir(directory):
            messagebox.showerror("错误", "目录无效")
            return
        for item in self.tree.get_children():
            file_name = self.tree.item(item, 'values')[0]
            file_path = os.path.join(directory, file_name)
            base, ext = os.path.splitext(file_name)
            new_name = self.random_string() + ext
            new_file_path = os.path.join(directory, new_name)
            os.rename(file_path, new_file_path)
            self.tree.item(item, values=(new_name, new_name, "未处理"))
        messagebox.showinfo("完成", "文件已随机重命名")
        self.update_status_bar("文件已随机重命名")

    def prefix_suffix(self):
        prefix = simpledialog.askstring("前缀", "请输入前缀:")
        suffix = simpledialog.askstring("后缀", "请输入后缀:")
        if prefix or suffix:
            directory = self.directory.get()
            if not os.path.isdir(directory):
                messagebox.showerror("错误", "目录无效")
                return
            for item in self.tree.get_children():
                file_name = self.tree.item(item, 'values')[0]
                file_path = os.path.join(directory, file_name)
                base, ext = os.path.splitext(file_name)
                new_name = (prefix or "") + base + (suffix or "") + ext
                new_file_path = os.path.join(directory, new_name)
                os.rename(file_path, new_file_path)
                self.tree.item(item, values=(new_name, new_name, "未处理"))
            messagebox.showinfo("完成", "前缀后缀已添加")
            self.update_status_bar("前缀后缀已添加")

    def numbering(self):
        start_num = simpledialog.askinteger("数字编号", "请输入起始编号:")
        if start_num is not None:
            directory = self.directory.get()
            if not os.path.isdir(directory):
                messagebox.showerror("错误", "目录无效")
                return
            for i, item in enumerate(self.tree.get_children(), start=start_num):
                file_name = self.tree.item(item, 'values')[0]
                file_path = os.path.join(directory, file_name)
                base, ext = os.path.splitext(file_name)
                new_name = f"{i}_{base}{ext}"
                new_file_path = os.path.join(directory, new_name)
                os.rename(file_path, new_file_path)
                self.tree.item(item, values=(new_name, new_name, "未处理"))
            messagebox.showinfo("完成", "文件已编号")
            self.update_status_bar("文件已编号")

    def change_case(self):
        choice = simpledialog.askstring("大小写转换", "请输入 'upper' 转为大写 或 'lower' 转为小写:")
        if choice in ['upper', 'lower']:
            directory = self.directory.get()
            if not os.path.isdir(directory):
                messagebox.showerror("错误", "目录无效")
                return
            for item in self.tree.get_children():
                file_name = self.tree.item(item, 'values')[0]
                file_path = os.path.join(directory, file_name)
                if choice == 'upper':
                    new_name = file_name.upper()
                else:
                    new_name = file_name.lower()
                new_file_path = os.path.join(directory, new_name)
                os.rename(file_path, new_file_path)
                self.tree.item(item, values=(new_name, new_name, "未处理"))
            messagebox.showinfo("完成", "大小写转换完成")
            self.update_status_bar("大小写转换完成")

    def extend_name(self):
        extension = simpledialog.askstring("扩展名称", "请输入要添加的扩展名（包括点）:")
        if extension:
            directory = self.directory.get()
            if not os.path.isdir(directory):
                messagebox.showerror("错误", "目录无效")
                return
            for item in self.tree.get_children():
                file_name = self.tree.item(item, 'values')[0]
                file_path = os.path.join(directory, file_name)
                base, ext = os.path.splitext(file_name)
                new_name = base + extension
                new_file_path = os.path.join(directory, new_name)
                os.rename(file_path, new_file_path)
                self.tree.item(item, values=(new_name, new_name, "未处理"))
            messagebox.showinfo("完成", "扩展名称已添加")
            self.update_status_bar("扩展名称已添加")

    def auto_translate(self):
        messagebox.showinfo("自动翻译", "此功能尚未实现。")
        self.update_status_bar("自动翻译功能尚未实现")

    def table_rename(self):
        messagebox.showinfo("表格改名", "此功能尚未实现。")
        self.update_status_bar("表格改名功能尚未实现")

    def text_rename(self):
        messagebox.showinfo("文本改名", "此功能尚未实现。")
        self.update_status_bar("文本改名功能尚未实现")

    def batch_create(self):
        messagebox.showinfo("批量新建", "此功能尚未实现。")
        self.update_status_bar("批量新建功能尚未实现")

    def backup_restore(self):
        messagebox.showinfo("备份还原", "此功能尚未实现。")
        self.update_status_bar("备份还原功能尚未实现")

    def generate_bat(self):
        messagebox.showinfo("生成BAT", "此功能尚未实现。")
        self.update_status_bar("生成BAT功能尚未实现")

    def contact_support(self):
        messagebox.showinfo("联系客服", "此功能尚未实现。")
        self.update_status_bar("联系客服功能尚未实现")
        
    def random_sort(self):
        directory = self.directory.get()
        if not os.path.isdir(directory):
            messagebox.showerror("错误", "目录无效")
            return
        files = os.listdir(directory)
        random.shuffle(files)
        for i, file in enumerate(files):
            base, ext = os.path.splitext(file)
            new_name = f"{i}_{base}{ext}"
            os.rename(os.path.join(directory, file), os.path.join(directory, new_name))
        messagebox.showinfo("完成", "文件已随机排序")
        self.update_status_bar("文件已随机排序")
        self.list_files()

    def number_sort(self):
        directory = self.directory.get()
        if not os.path.isdir(directory):
            messagebox.showerror("错误", "目录无效")
            return
        files = os.listdir(directory)
        files.sort()
        for i, file in enumerate(files):
            base, ext = os.path.splitext(file)
            new_name = f"{i+1}_{base}{ext}"
            os.rename(os.path.join(directory, file), os.path.join(directory, new_name))
        messagebox.showinfo("完成", "文件已按数字排序")
        self.update_status_bar("文件已按数字排序")
        self.list_files()

    def crazy_shuffle(self):
        directory = self.directory.get()
        if not os.path.isdir(directory):
            messagebox.showerror("错误", "目录无效")
            return
        files = os.listdir(directory)
        random.shuffle(files)
        for file in files:
            new_name = ''.join(random.choices(string.ascii_letters + string.digits, k=len(file)))
            os.rename(os.path.join(directory, file), os.path.join(directory, new_name))
        messagebox.showinfo("完成", "文件已疯狂乱序")
        self.update_status_bar("文件已疯狂乱序")
        self.list_files()

    def list_files(self):
        # 清空当前Treeview内容
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        directory = self.directory.get()
        if not os.path.isdir(directory):
            messagebox.showerror("错误", "目录无效")
            return
        files = [f for f in os.listdir(directory) if os.path.isfile(os.path.join(directory, f))]
        
        # 添加文件到Treeview
        for file in files:
            file_path = os.path.join(directory, file)
            self.tree.insert("", tk.END, values=(file, file, "未处理"))
        
        self.update_status_bar(f"当前目录包含 {len(files)} 个文件")

    def simplified_traditional(self):
        messagebox.showinfo("繁简转换", "此功能尚未实现。")
        self.update_status_bar("繁简转换功能尚未实现")

    def switch_interface(self):
        messagebox.showinfo("切换界面", "此功能尚未实现。")
        self.update_status_bar("切换界面功能尚未实现")

if __name__ == "__main__":
    root = tk.Tk()
    app = FileManagerApp(root)
    root.mainloop()
