import os
import requests
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext, ttk
import random
from PIL import Image, ImageTk

def download_images(urls, save_dir):
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)

    for i, url in enumerate(urls):
        try:
            response = requests.get(url)
            response.raise_for_status()

            file_path = os.path.join(save_dir, f"image_{i+1}.gif")
            with open(file_path, "wb") as file:
                file.write(response.content)
            print(f"下载成功: {file_path}")
        except requests.exceptions.RequestException as e:
            print(f"下载失败 {url}: {e}")

def start_download():
    urls = url_text.get("1.0", tk.END).strip().split("\n")
    save_dir = filedialog.askdirectory()
    if not save_dir:
        return

    download_images(urls, save_dir)
    messagebox.showinfo("提示", "下载完成")

def add_files():
    file_paths = filedialog.askopenfilenames(filetypes=[("GIF 文件", "*.gif")])
    for path in file_paths:
        url_text.insert(tk.END, path + '\n')

def select_directory():
    directory = filedialog.askdirectory()
    if directory:
        save_dir.set(directory)

def rename_files(method):
    directory = save_dir.get()
    if not directory:
        messagebox.showerror("错误", "请先选择目录")
        return

    filter_pattern = filter_text.get().strip()
    files = [f for f in os.listdir(directory) if f.endswith(".gif") and filter_pattern in f]
    
    if method == "数字编号":
        for i, filename in enumerate(files):
            new_name = f"image_{i+1}.gif"
            os.rename(os.path.join(directory, filename), os.path.join(directory, new_name))
    
    elif method == "数字排序":
        files.sort()
        for i, filename in enumerate(files):
            new_name = f"image_{i+1}.gif"
            os.rename(os.path.join(directory, filename), os.path.join(directory, new_name))
    
    elif method == "随机命名":
        for filename in files:
            random_name = f"image_{random.randint(1000, 9999)}.gif"
            os.rename(os.path.join(directory, filename), os.path.join(directory, random_name))
    
    elif method == "疯狂乱序":
        random.shuffle(files)
        for i, filename in enumerate(files):
            new_name = f"image_{i+1}.gif"
            os.rename(os.path.join(directory, filename), os.path.join(directory, new_name))

    messagebox.showinfo("提示", f"{method} 完成")

def create_menu(app):
    menubar = tk.Menu(app)

    filemenu = tk.Menu(menubar, tearoff=0)
    filemenu.add_command(label="添加文件", command=add_files)
    filemenu.add_command(label="选择目录", command=select_directory)
    filemenu.add_command(label="下载", command=start_download)
    menubar.add_cascade(label="文件", menu=filemenu)

    rename_menu = tk.Menu(menubar, tearoff=0)
    rename_menu.add_command(label="数字编号", command=lambda: rename_files("数字编号"))
    rename_menu.add_command(label="数字排序", command=lambda: rename_files("数字排序"))
    rename_menu.add_command(label="随机命名", command=lambda: rename_files("随机命名"))
    rename_menu.add_command(label="疯狂乱序", command=lambda: rename_files("疯狂乱序"))
    menubar.add_cascade(label="重命名", menu=rename_menu)

    app.config(menu=menubar)

def on_enter(event):
    event.widget.config(bg="#d5d5d5")

def on_leave(event):
    event.widget.config(bg="#3498db")

def show_help():
    messagebox.showinfo("使用方法", "1. 在输入框中输入要下载的图片URL，每行一个。\n"
                                    "2. 使用“添加文件”按钮选择本地文件。\n"
                                    "3. 使用“选择目录”按钮选择保存目录。\n"
                                    "4. 点击“下载”按钮开始下载图片。\n"
                                    "5. 使用菜单栏中的重命名选项对文件进行重命名。")

app = tk.Tk()
app.title("GIF 图片下载器")
app.geometry("800x600")

create_menu(app)

# 主框架
main_frame = tk.Frame(app, bg="#f7f7f7", padx=10, pady=10)
main_frame.pack(fill="both", expand=True)

# URL输入区域
url_frame = tk.LabelFrame(main_frame, text="输入 URL（每行一个）:", bg="#f7f7f7", padx=10, pady=10)
url_frame.pack(fill="both", padx=10, pady=10)

url_text = scrolledtext.ScrolledText(url_frame, width=80, height=10, bg="#ffffff", fg="#000000", insertbackground="#000000")
url_text.pack(fill="both", expand=True)

# 保存目录和过滤模式
filter_frame = tk.LabelFrame(main_frame, text="保存目录和过滤模式", bg="#f7f7f7", padx=10, pady=10)
filter_frame.pack(fill="both", padx=10, pady=10)

save_dir = tk.StringVar()
save_entry = tk.Entry(filter_frame, textvariable=save_dir, width=80, bg="#ffffff", fg="#000000", insertbackground="#000000")
save_entry.pack(fill="x", pady=5)

filter_text = tk.Entry(filter_frame, width=80, bg="#ffffff", fg="#000000", insertbackground="#000000")
filter_text.pack(fill="x", pady=5)

# 操作按钮
button_frame = tk.Frame(main_frame, bg="#f7f7f7")
button_frame.pack(fill="x", padx=10, pady=10)

add_button = tk.Button(button_frame, text="添加文件", command=add_files, bg="#3498db", fg="white", font=("Helvetica", 12), relief="flat", bd=2)
add_button.bind("<Enter>", on_enter)
add_button.bind("<Leave>", on_leave)
add_button.pack(side="left", padx=5, pady=5)

select_button = tk.Button(button_frame, text="选择目录", command=select_directory, bg="#3498db", fg="white", font=("Helvetica", 12), relief="flat", bd=2)
select_button.bind("<Enter>", on_enter)
select_button.bind("<Leave>", on_leave)
select_button.pack(side="left", padx=5, pady=5)

download_button = tk.Button(button_frame, text="下载", command=start_download, bg="#e74c3c", fg="white", font=("Helvetica", 12), relief="flat", bd=2)
download_button.bind("<Enter>", on_enter)
download_button.bind("<Leave>", on_leave)
download_button.pack(side="left", padx=5, pady=5)

help_button = tk.Button(button_frame, text="使用方法", command=show_help, bg="#2ecc71", fg="white", font=("Helvetica", 12), relief="flat", bd=2)
help_button.bind("<Enter>", on_enter)
help_button.bind("<Leave>", on_leave)
help_button.pack(side="left", padx=5, pady=5)

# 状态栏
status_frame = tk.Frame(app, bd=1, relief=tk.SUNKEN)
status_frame.pack(side=tk.BOTTOM, fill=tk.X)

status_label = tk.Label(status_frame, text="状态：", anchor=tk.W)
status_label.pack(fill=tk.X)

app.mainloop()
