import requests
import socket
import time

def test_proxy_ip(proxy_ip, port, username, password, test_url='https://httpbin.org/ip'):
    '''
    proxy_ip:ip地址
    port:端口
    username:账号
    password:密码
    '''
    proxy_url = f"http://{username}:{password}@{proxy_ip}:{port}"
    proxies = {
        "http": proxy_url,
        "https": proxy_url,
    }
    try:
        response = requests.get(test_url, proxies=proxies, timeout=60)
        response.raise_for_status()  # 对错误响应抛出HTTPError
        print(f"代理IP {proxy_ip}:{port} 工作正常。响应: {response.json()}")
    except requests.RequestException as e:
        print(f"代理IP {proxy_ip}:{port} 无法工作。错误: {e}")

def nextip(proxy_ip, port, username, password):
    '''
    proxy_ip:ip地址
    port:端口
    username:账号
    password:密码
    '''
    proxy_url = f"http://{username}:{password}@{proxy_ip}:{port}"
    proxies = {
        "http": proxy_url,
        "https": proxy_url,
    }
    try:
        return proxies
    except requests.RequestException as e:
        print(f"代理IP {proxy_ip}:{port} 发生错误。错误: {e}")



def is_ip_available(ip, port):
    try:
        socket.setdefaulttimeout(1)
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.connect((ip, int(port)))
        sock.close()
        return True
    except Exception:
        return False

def get_available_ip():
    params = {
        'secret': '98c99f97d4f8e3883299688a916b0188',
        'orderNo': 'VGL20240521163346i8t2ky45',
        'count': '1',  # 获取10个IP
        'isTxt': '0',
        'proxyType': '1',
        'returnAccount': '2',
    }
    
    for attempt in range(2):  # 最多尝试两次
        response = requests.get(
            'http://pandavip.xiongmaodaili.com/xiongmao-web/apiPlus/vgl',
            params=params,
            verify=False,
        )

        if response.status_code != 200:
            print(f"Error: Received response with status code {response.status_code}")
            continue
        
        data = response.json()
        
        if 'obj' in data:
            proxy_list = data['obj']
            
            # 检查每个IP是否可用
            for proxy_info in proxy_list:
                proxy_ip = proxy_info['ip']
                port = proxy_info['port']
                if is_ip_available(proxy_ip, port):
                    return proxy_info
        else:
            print("Error: 'obj' key not found in response data")
            print("Response data:", data)
            time.sleep(1)  # 等待1秒后再次尝试
    return None

# 调用方法获取可用IP，添加时间限制
def ip():
    start_time = time.time()
    while True:
        available_ip = get_available_ip()
        if available_ip:
            return available_ip
        else:
            elapsed_time = time.time() - start_time
            if elapsed_time < 1:  # 控制每秒只调用一次API
                time.sleep(1 - elapsed_time)
            start_time = time.time()



