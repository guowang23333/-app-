from fastapi import FastAPI, HTTPException, Query, Form, Body
from fastapi.staticfiles import StaticFiles
import requests
from bs4 import BeautifulSoup
import mysql.connector
from mysql.connector import Error
from datetime import datetime
from pydantic import BaseModel
from PIL import Image
from io import BytesIO
import random
import string
import time
from typing import List, Optional
import uvicorn
from fastapi.middleware.cors import CORSMiddleware
from datetime import datetime, timedelta
import pandas as pd
import numpy as np
import re
from ip import ip,nextip
from fake_useragent import UserAgent
from concurrent.futures import ThreadPoolExecutor, as_completed
import hmac
from hashlib import sha1
import base64
from fastapi.middleware.cors import CORSMiddleware

def convert_rating_to_description(rating_value):
    if rating_value == 1:
        return '很差'
    elif rating_value == 2:
        return '较差'
    elif rating_value == 3:
        return '还行'
    elif rating_value == 4:
        return '推荐'
    elif rating_value == 5:
        return '力荐'
    else:
        return None
    
def generate_random_user_agent():
    ua = UserAgent()
    return ua.random
cookies = {
}
headers = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'Accept-Language': 'zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',
    'Pragma': 'no-cache',
    'Referer': 'https://movie.douban.com/subject/36777988/',
    'Sec-Fetch-Dest': 'document',
    'Sec-Fetch-Mode': 'navigate',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-Fetch-User': '?1',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    'sec-ch-ua': '"Chromium";v="124", "Google Chrome";v="124", "Not-A.Brand";v="99"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
}
# 这是获取用户id

#ip获取
def fetch_proxies():
    ipadd=ip()
    proxy_ip = ipadd['ip']
    port = ipadd['port']
    username = ipadd['account']
    password = ipadd['password']
    proxies=nextip(proxy_ip,port,username,password)
    return proxies

app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    
)
mysql_host = '127.0.0.1'
# 数据库连接配置
def get_db_connection():
    return mysql.connector.connect(
        host=mysql_host,
        user="root",
        password="root",
        database="douban",
        charset='utf8mb4',
        collation='utf8mb4_unicode_ci'
    )

@app.post("/scrape/{subjectids}")
def scrape_data(subjectids: str):
    # 将subjectids拆分为单个subject id
    subject_ids = subjectids.split(',')
    # 获取单个subject的评论
    def scrape_subject(subjectid):
        all_comments = []
        proxies = fetch_proxies()  # 获取代理
        time.sleep(1)
        request_count = 0
        # 获取单个评论页的评论
        def fetch_comments(start):
            nonlocal proxies, request_count
            # 每请求10次，更新一次代理
            if request_count % 10 == 0:
                proxies = fetch_proxies()
            try:
                # 构建请求URL和参数
                url = f'https://m.douban.com/rexxar/api/v2/movie/{subjectid}/interests'
                params = {
                    'count': '50',
                    'order_by': 'latest',
                    'anony': '0',
                    'start': start,
                    'ck': '',
                    'for_mobile': '1',
                }
                # 发送请求
                response = requests.get(url, headers=headers, proxies=proxies, params=params)
                response.raise_for_status()
                data = response.json()
                # 如果数据为空或者没有'interests'键，返回空列表
                if not data or 'interests' not in data:
                    return []
                # 解析评论数据
                comments_data = [
                    {
                        'user_id': interest['user']['id'],
                        'name': interest['user']['name'],
                        'comment': interest.get('comment'),
                        'create_time': interest.get('create_time'),
                        'location': interest.get('ip_location'),
                        'rating': convert_rating_to_description(interest['rating']['value']),
                        'subjectid': subjectid
                    }
                    for interest in data['interests']
                    if interest.get('user') and interest.get('rating')
                ]
                request_count += 1
                time.sleep(1)

                return comments_data
            except requests.exceptions.RequestException as e:
                # 请求异常处理
                print(f"Error fetching comments for start={start}: {e}")
                proxies = fetch_proxies()  # 更新代理
                return []

        # 使用线程池并发请求评论页，每隔1秒启动一个线程
        with ThreadPoolExecutor(max_workers=20) as executor:
            futures = []
            for start in range(50, 2000, 50):
                print(start)
                futures.append(executor.submit(fetch_comments, start))
                time.sleep(1)  # 每隔1秒启动一个线程
            print('下一步')
            for future in as_completed(futures):
                all_comments.extend(future.result())

        return all_comments

    # 存储所有subject的评论
    all_subject_comments = []

    # 使用线程池并发请求每个subject的评论
    with ThreadPoolExecutor(max_workers=len(subject_ids)) as executor:
        time.sleep(1)
        # 为每个subject id提交一个任务，任务是调用scrape_subject函数
        futures = [executor.submit(scrape_subject, int(subjectid)) for subjectid in subject_ids]
        # 遍历所有已完成的futures
        for future in as_completed(futures):
            # 获取每个future的结果，并将其扩展到all_subject_comments列表中
            all_subject_comments.extend(future.result())


    # 将评论插入数据库
    try:
        db = get_db_connection()
        cursor = db.cursor()
        for comment_info in all_subject_comments:
            cursor.execute(
                "INSERT INTO comments (user_name, user_id, comment_content, comment_time, location, rating, subjectid) VALUES (%s, %s, %s, %s, %s, %s, %s)",
                (comment_info['name'], comment_info['user_id'], comment_info['comment'],
                 comment_info['create_time'], comment_info['location'], comment_info['rating'],
                 comment_info['subjectid'])
            )
        db.commit()
    except Exception as e:
        # 数据库插入异常处理
        print(f"Error writing comments to the database: {e}")
    finally:
        cursor.close()
        db.close()

    # 返回成功信息
    return {"status": "success", "message": "数据已成功插入"}


db_config = {
    'host': mysql_host,
    'user': 'root',
    'password': 'root',  # 修改为你的数据库密码
    'database': 'douban',
    'charset': 'utf8mb4',
    'collation': 'utf8mb4_unicode_ci'
}


def connect_db():
    try:
        conn = mysql.connector.connect(**db_config)
        return conn
    except Error as e:
        print(f"Error connecting to MySQL Platform: {e}")
        return None


@app.get("/user/{user_id}/movies")
def get_movies_and_update_user_info(user_id: str):
    proxies = fetch_proxies()
    conn = connect_db()
    if conn is None:
        raise HTTPException(status_code=500, detail="无法连接到数据库")

    movie_types = {
        "watching": "do",   # 在看
        "wish": "wish",     # 想看
        "watched": "collect"  # 看过
    }

    cursor = conn.cursor()
    try:
        for movie_status, path in movie_types.items():
            for start in range(0, 100, 15):
                try:
                    movie_url = f"https://movie.douban.com/people/{user_id}/{path}?start={start}&sort=time&rating=all&mode=grid&type=all&filter=all"
                    response = requests.get(movie_url, headers=headers, proxies=proxies)
                    if response.status_code != 200:
                        print(f"HTTP错误: {response.status_code}")
                        continue
                    soup = BeautifulSoup(response.text, 'html.parser')
                    items = soup.find_all('div', class_='item')

                    for item in items:
                        title_tag = item.find('li', class_='title').find('a')
                        title = title_tag.text.strip()
                        url = title_tag['href']

                        match = re.search(r"subject/(\d+)/", url)
                        douban_id = match.group(1) if match else None
                        date_tag = item.find('span', class_='date')
                        watch_date = date_tag.text.strip() if date_tag else None

                        comment_tag = item.find('span', class_='comment')
                        comment = comment_tag.text.strip() if comment_tag else None

                        rating_tag = item.find('span', class_=lambda x: x and 'rating' in x)
                        star_rating = {
                            'rating5-t': "力荐",
                            'rating4-t': "推荐",
                            'rating3-t': "还行",
                            'rating2-t': "较差",
                            'rating1-t': "很差"
                        }.get(rating_tag['class'][0], "未评分") if rating_tag else "未评分"

                        cursor.execute(
                            "INSERT INTO comments (user_id, movie_status, title, url, comment_time, comment_content, rating, subjectid) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)",
                            (user_id, movie_status, title, url, watch_date, comment, star_rating, douban_id))
                except Exception as e:
                    print(f"错误: {e}")
                    continue

        cursor.close()
        cursor = conn.cursor()

        url = f"https://www.douban.com/people/{user_id}/"
        response = requests.get(url, headers=headers, proxies=proxies)

        soup = BeautifulSoup(response.text, 'html.parser')

        try:
            basic_info = soup.find('div', class_='basic-info')
            join_info = basic_info.find('div', class_='pl').text.strip()
            join_date = join_info.split('\n')[1].replace('加入', '').strip()
            join_date = datetime.strptime(join_date, "%Y-%m-%d").date()
            join_date_str = join_date.strftime('%Y-%m-%d')
        except Exception as e:
            join_date_str = None

        try:
            movie_section = soup.find('div', id='movie')
            watching_count = movie_section.find('a', href=lambda x: x and 'do' in x).text.split()[0]
            want_to_watch_count = movie_section.find('a', href=lambda x: x and 'wish' in x).text.split()[0]
            watched_count = movie_section.find('a', href=lambda x: x and 'collect' in x).text.split()[0]
        except Exception as e:
            watching_count = want_to_watch_count = watched_count = "Not available"

        cursor.execute("SELECT user_name, location FROM comments WHERE user_id = %s", (user_id,))
        user_data = cursor.fetchone()
        cursor.fetchall()  # 确保处理所有结果集

        if user_data:
            user_name, location = user_data
        else:
            raise HTTPException(status_code=404, detail="用户未找到")

        sql_update = """
        UPDATE comments
        SET user_name = %s, location = %s, movie_watching = %s, movie_want_to_watch = %s, movie_watched = %s, join_date= %s
        WHERE user_id = %s
        """
        values = (user_name, location, watching_count, want_to_watch_count, watched_count, join_date_str, user_id)

        cursor.execute(sql_update, values)
        conn.commit()
        user_message = "用户信息已成功更新"

    except Exception as e:
        conn.rollback()
        print(f"错误: {e}")
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        cursor.close()
        conn.close()

    return {"status": "success", "message": user_message}

@app.post("/login/")
async def login(data: dict = Body(...)):
    device_id = "811829c2cb430ef800c8153d4ac248bb3f5a195f"
    headers = {
        'User-Agent': f'api-client/1 com.douban.frodo/7.18.0(230) Android/28 product/M973Q vendor/Meizu model/M973Q brand/Meizu  rom/flyme4  network/wifi  udid/{device_id}  platform/AndroidPad',
        'Content-Type': 'application/x-www-form-urlencoded',
        'Host': 'frodo.douban.com',
        'Connection': 'Keep-Alive',
    }

    username = data.get('username')
    password = data.get('password')

    if not username or not password:
        return {"message": "用户名或密码为空"}

    payload = {
        'client_id': '0dad551ec0f84ed02907ff5c42e8ec70',
        'client_secret': 'bf7dddc7c9cfe6f7',
        'grant_type': 'password',
        'username': username,
        'password': password,
    }

    response = requests.post('https://frodo.douban.com/service/auth2/token?timezone=Asia%2FShanghai', data=payload, headers=headers)
    data2 = response.json()

    print("Response from Douban:", data2)  # 打印响应数据以便调试

    if data2.get('code') == 9000:
        user_id = data2['extra']['solution_uri'].split('user_id=')[1]
        return {"message": "需要验证码", "user_id": user_id}

    if 'access_token' in data2:
        try:
            conn = mysql.connector.connect(**db_config)
            cursor = conn.cursor()

            # 插入或更新用户数据
            sql_insert_update = """
            INSERT INTO user (user_id, ck, douban_user_name) 
            VALUES (%s, %s, %s)
            ON DUPLICATE KEY UPDATE
            ck = VALUES(ck), douban_user_name = VALUES(douban_user_name)
            """
            values = (data2['douban_user_id'], data2['access_token'], data2['douban_user_name'])
            cursor.execute(sql_insert_update, values)
            conn.commit()

        except Error as e:
            print(f"Error: {e}")
            raise HTTPException(status_code=500, detail="数据库操作失败")
        finally:
            if (conn.is_connected()):
                cursor.close()
                conn.close()

        return {
            "message": "登录成功",
            "access_token": data2['access_token'],
            "douban_user_name": data2['douban_user_name'],
            "douban_user_id": data2['douban_user_id'],
            "expires_in": data2['expires_in'],
            "refresh_token": data2['refresh_token']
        }

    return data2

@app.post("/verify_phone/")
async def verify_phone(data: dict = Body(...)):
    device_id = "811829c2cb430ef800c8153d4ac248bb3f5a195f"
    headers = {
        'Host': 'accounts.douban.com',
        'Connection': 'keep-alive',
        'Accept': 'application/json, text/plain, */*',
        'X-CSRF-TOKEN': 'undefined',
        'User-Agent': f'Mozilla/5.0 (Linux; Android 9; M973Q Build/PQ3B.190801.05311404; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/91.0.4472.114 Mobile Safari/537.36 udid/{device_id} com.douban.frodo/7.18.0(230) DoubanApp',
        'Origin': 'https://accounts.douban.com',
        'X-Requested-With': 'com.douban.frodo',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Dest': 'empty',
        'Referer': 'https://accounts.douban.com/passport/verify_phone?user_id=279936972&dark_mode=0',
        'Accept-Language': 'zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7',
    }

    user_id = data.get('user_id')
    payload = {
        'user_id': user_id,
        'apikey': '0dad551ec0f84ed02907ff5c42e8ec70',
    }

    response = requests.post('https://accounts.douban.com/j/app/verify_phone/request_phone_code', headers=headers, data=payload)
    data2 = response.json()
    print("Response from verify_phone:", data2)  # 打印响应数据以便调试

    if data2.get('description') == '处理成功':
        return {
            "success": True,
            "message": "验证码发送成功"
        }
    else:
        raise HTTPException(status_code=400, detail="验证码发送失败")

@app.post("/verify_code/")
async def verify_code(data: dict = Body(...)):
    device_id = "811829c2cb430ef800c8153d4ac248bb3f5a195f"
    headers = {
        'Host': 'accounts.douban.com',
        'Connection': 'keep-alive',
        'Accept': 'application/json, text/plain, */*',
        'X-CSRF-TOKEN': 'undefined',
        'User-Agent': f'Mozilla/5.0 (Linux; Android 9; M973Q Build/PQ3B.190801.05311404; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/91.0.4472.114 Mobile Safari/537.36 udid/{device_id} com.douban.frodo/7.18.0(230) DoubanApp',
        'Origin': 'https://accounts.douban.com',
        'X-Requested-With': 'com.douban.frodo',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Dest': 'empty',
        'Referer': 'https://accounts.douban.com/passport/verify_phone?user_id=279936972&dark_mode=0',
        'Accept-Language': 'zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7',
    }

    user_id = data.get('user_id')
    phone_code = data.get('phone_code')
    payload = {
        'client_id': '0dad551ec0f84ed02907ff5c42e8ec70',
        'user_id': user_id,
        'phone_code': phone_code,
        'randstr': '@GX2',
        'tc_app_id': '2044348370',
        'apikey': '0dad551ec0f84ed02907ff5c42e8ec70',
    }
    response = requests.post('https://accounts.douban.com/j/app/verify_phone/verify_phone_code', headers=headers, data=payload)
    data2 = response.json()
    print("Response from verify_code:", data2)

    if data2.get('description') == '处理成功':
        try:
            conn = mysql.connector.connect(**db_config)
            cursor = conn.cursor()

            # 插入或更新用户数据
            sql_insert_update = """
            INSERT INTO user (user_id, ck, douban_user_name) 
            VALUES (%s, %s, %s)
            ON DUPLICATE KEY UPDATE
            ck = VALUES(ck), douban_user_name = VALUES(douban_user_name)
            """
            values = (data2['payload']['douban_user_id'], data2['payload']['access_token'], data2['payload']['douban_user_name'])
            cursor.execute(sql_insert_update, values)
            conn.commit()

            user_message = "用户信息已成功保存"
        except Error as e:
            print(f"Error: {e}")
            raise HTTPException(status_code=500, detail="数据库操作失败")
        finally:
            if (conn.is_connected()):
                cursor.close()
                conn.close()

        return {
            "success": True,
            "message": "登录成功",
            "access_token": data2['payload']['access_token'],
            "user": {
                "douban_user_id": data2['payload']['douban_user_id'],
                "douban_user_name": data2['payload']['douban_user_name']
            }
        }
    else:
        raise HTTPException(status_code=400, detail="验证码错误或处理失败")

class Option(BaseModel):
    id: Optional[str] = None
    name: Optional[str] = None
    votes: Optional[str] = None
    tag: Optional[str] = None
    comment_time: Optional[str] = None
    location: Optional[str] = None
    comment_content: Optional[str] = None
    rating:Optional[str] = None
@app.get("/database/options", response_model=List[Option])
async def get_database_options():
    db = get_db_connection()
    if db is None:
        raise HTTPException(status_code=500, detail="Database connection failed")

    cursor = db.cursor()
    rating_mapping = {
    "wish": "想看",
    "watching": "在看",
    "watched": "看过"
    }
    star_rating_mapping = {
        "力荐": "5星",
        "推荐": "4星",
        "还行": "3星",
        "较差": "2星",
        "很差": "1星"
    }
    try:
        cursor.execute(
            "SELECT DISTINCT user_id, user_name, votes, rating, join_date, location, comment_content, movie_status FROM comments"
        )
        rows = cursor.fetchall()
        options = [
            Option(
                id=row[0],
                name=row[1] if row[1] else None,
                votes=row[2] if row[2] is not None else None,
                tag = star_rating_mapping.get(row[3], None) if row[3] is not None else None,
                comment_time=row[4] if row[4] is not None else None,
                location=row[5] if row[5] else None,
                comment_content=row[6] if row[6] else None,
                rating = rating_mapping.get(row[7], None)
            ) for row in rows
        ]
    except mysql.connector.Error as error:
        cursor.close()
        db.close()
        raise HTTPException(status_code=500, detail=str(error))

    cursor.close()
    db.close()
    return options


# 这里添加一个可选的查询参数 subjectid
@app.get("/comments/", response_model=List[Option])
async def get_comments(subjectid: Optional[int] = None):
    db = get_db_connection()
    if db is None:
        raise HTTPException(status_code=500, detail="Database connection failed")

    cursor = db.cursor()
    try:
        if subjectid is None:
            # 如果没有提供subjectid，则加载所有评论
            query = "SELECT DISTINCT user_id, user_name, votes, rating, join_date, location, comment_content FROM comments"
        else:
            # 使用subjectid进行筛选
            query = f"SELECT DISTINCT user_id, user_name, votes, rating, join_date, location, comment_content FROM comments WHERE subjectid = {subjectid}"

        cursor.execute(query)
        rows = cursor.fetchall()
        options = [
            Option(
                id=row[0],
                name=row[1],
                votes=row[2],
                rating=row[3],
                comment_time=row[4].strftime('%Y-%m-%d %H:%M:%S') if isinstance(row[4], datetime) else row[4],
                location=row[5],
                comment_content=row[6]
            ) for row in rows
        ]
    except mysql.connector.Error as error:
        db.close()
        raise HTTPException(status_code=500, detail=str(error))

    cursor.close()
    db.close()
    return options


@app.get("/comments/recent/", response_model=List[Option])
async def get_recent_comments(
        days_back: Optional[int] = Query(7, description="Number of days back to fetch comments from")):
    db = get_db_connection()
    if db is None:
        raise HTTPException(status_code=500, detail="Database connection failed")

    cursor = db.cursor()
    try:
        # 计算目标日期
        target_date = datetime.now() - timedelta(days=days_back)
        query = f"""
        SELECT DISTINCT user_id, user_name, votes, rating, comment_time, location, comment_content 
        FROM comments 
        WHERE comment_time >= '{target_date.strftime('%Y-%m-%d %H:%M:%S')}'
        """
        cursor.execute(query)
        rows = cursor.fetchall()
        options = [
            Option(
                id=row[0],
                name=row[1],
                votes=row[2],
                rating=row[3],
                comment_time=row[4],
                location=row[5],
                comment_content=row[6]
            ) for row in rows
        ]
    except mysql.connector.Error as error:
        db.close()
        raise HTTPException(status_code=500, detail=str(error))
    finally:
        cursor.close()
        db.close()

    return options


class Item(BaseModel):
    cookies: dict
    data: dict


def hash_hmac(code):
    key = "bf7dddc7c9cfe6f7"
    hmac_code = hmac.new(key.encode(), code.encode(), sha1).digest()
    return base64.b64encode(hmac_code).decode()

@app.post("/send_greeting/")
async def send_greeting(data: dict = Body(...)):
    device_id = "a1dfffee6bbb886ae59fffcb4332993e"
    uid=data['data']['to']#需要发送的uid
    #uid=172937701
    access_token=data['data']['ck']#登陆需要的token
    m_text=data['data']['m_text']
    #m_text=1137929
    t = time.time()
    req_url = f"POST&%2Fapi%2Fv2%2Fuser%2F{uid}%2Fchat%2Fshare_object&{access_token}&{format(int(t))}"
    sign = hash_hmac(req_url)
    headers = {
        'Authorization': f'Bearer {access_token}',#鉴权，你没猜错这里也是正常鉴权完毕后access_token返回的值
        'User-Agent': f'api-client/1 com.douban.frodo/7.18.0(230) Android/28 product/M973Q vendor/Meizu model/M973Q brand/Meizu  rom/flyme4  network/wifi  udid/{device_id}  platform/AndroidPad',
        #他奶奶的我怀疑这里也是有鉴权的udid/40c28e69a81dd89281bb474fbacd2d7faa164a3d嗯最好固定一下，要不到最后健全全部失败就好玩了
        'Accept-Encoding': 'br,gzip',
        'Content-Type': 'application/x-www-form-urlencoded',
        'Host': 'frodo.douban.com',
        'Connection': 'Keep-Alive',
        'Content-Length': '210',
    }
    data = {
        'id': f'{m_text}',#uid上边有些
        'type': 'user',
        'subtype': 'movie',
        'apikey': '0dad551ec0f84ed02907ff5c42e8ec70',#签名不能动
        'channel': 'ali_market',
        'udid': '40c28e69a81dd89281bb474fbacd2d7faa164a3d',#设备号
        'os_rom': 'flyme4',
        '_sig': sign,#加密值
        '_ts': int(t),#时间戳 10位的
    }
    response = requests.post(
        f'https://frodo.douban.com/api/v2/user/{uid}/chat/share_object?timezone=Asia%2FShanghai',
        headers=headers,
        data=data,
    )
    data=response.json()
    print(data)
    try:
        response.raise_for_status()
    except requests.exceptions.HTTPError as e:
        raise HTTPException(status_code=response.status_code, detail=str(e))
    return response.json()
@app.post("/send_text/")
async def send_text(data: dict = Body(...)):
    device_id = "a1dfffee6bbb886ae59fffcb4332993e"
    uid=data['data']['to']#需要发送的uid
    #uid=172937701
    access_token=data['data']['ck']#登陆需要的token
    m_text=data['data']['m_text']
    #m_text=1137929
    t = time.time()
    req_url = f"POST&%2Fapi%2Fv2%2Fuser%2F{uid}%2Fchat%2Fcreate_message&{access_token}&{format(int(t))}"
    sign = hash_hmac(req_url)
    headers = {
        'Authorization': f'Bearer {access_token}',#鉴权，你没猜错这里也是正常鉴权完毕后access_token返回的值
        'User-Agent': f'api-client/1 com.douban.frodo/7.18.0(230) Android/28 product/M973Q vendor/Meizu model/M973Q brand/Meizu  rom/flyme4  network/wifi  udid/{device_id}  platform/AndroidPad',
        #他奶奶的我怀疑这里也是有鉴权的udid/40c28e69a81dd89281bb474fbacd2d7faa164a3d嗯最好固定一下，要不到最后健全全部失败就好玩了
        'Accept-Encoding': 'br,gzip',
        'Content-Type': 'application/x-www-form-urlencoded',
        'Host': 'frodo.douban.com',
        'Connection': 'Keep-Alive',
        'Content-Length': '210',
    }

    data = {
    'nonce': int(round(t * 1000)),
    'text': m_text,
    'apikey': '0dad551ec0f84ed02907ff5c42e8ec70',
    'channel': 'ali_market',
    'udid': '811829c2cb430ef800c8153d4ac248bb3f5a196d',
    'os_rom': 'flyme4',
    '_sig': sign,
    '_ts': int(t),
    }
    response = requests.post(
        f'https://frodo.douban.com/api/v2/user/{uid}/chat/create_message?timezone=Asia%2FShanghai',
        headers=headers,
        data=data,
    )
    data=response.json()
    print(data)
    try:
        response.raise_for_status()
    except requests.exceptions.HTTPError as e:
        raise HTTPException(status_code=response.status_code, detail=str(e))
    return response.json()
# 获取ip
@app.get("/get_ip/")
async def get_ip():
    try:
        return [
            {'id': 1, 'ip': '1.1.1.1', 'port': 1, 'save_time': '2024-05-07 14:12:12',
             'exp_time': '2024-05-07 14:13:12'},
            {'id': 2, 'ip': '2.2.2.2', 'port': 2, 'save_time': '2024-05-07 14:12:12',
             'exp_time': '2024-05-07 14:13:12'},
            {'id': 3, 'ip': '3.3.3.3', 'port': 3, 'save_time': '2024-05-07 14:12:12',
             'exp_time': '2024-05-07 14:13:12'},
        ]
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.get("/save_ip/")
async def save_ip():
    try:
        fetch_proxies()
        return {'code': 'success'}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.get("/delete_ip/")
async def save_ip():
    try:
        # 入参格式 {'id': 'xxxx'}
        return {'code': 'success'}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


class GenerateParams(BaseModel):
    template: str = "K93ZANX4bjc"


@app.get("/generate-similar-string/")
def generate_similar_string(params: GenerateParams):
    template = params.template
    result = []
    for char in template:
        if char.isdigit():
            new_char = random.choice(string.digits)
        elif char.isupper():
            new_char = random.choice(string.ascii_uppercase)
        elif char.islower():
            new_char = random.choice(string.ascii_lowercase)
        else:
            new_char = char
        result.append(new_char)
    return {'result': ''.join(result)}


@app.get("/generate-random-value/")
def generate_random_value():
    hex_part = ''.join(random.choices('0123456789abcdef', k=16))
    timestamp_part = int(time.time())
    return {'result': f"{hex_part}.{timestamp_part}"}


def show_image(data):
    try:
        image = Image.open(BytesIO(data))
        image.show()
    except Exception as e:
        return f"Error showing image: {e}"


class User(BaseModel):
    id: int
    douban_user_name: str
    user_id: str
    ck: str
@app.get("/users/", response_model=List[User])
async def read_users():
    db = get_db_connection()
    if db is None:
        raise HTTPException(status_code=500, detail="数据库连接失败")

    cursor = db.cursor()
    try:
        cursor.execute("SELECT id, douban_user_name, user_id, ck FROM user")
        rows = cursor.fetchall()
        users = [User(id=row[0], douban_user_name=row[1], user_id=row[2], ck=row[3]) for row in rows]
    except mysql.connector.Error as error:
        db.close()
        raise HTTPException(status_code=500, detail=str(error))
    finally:
        cursor.close()
        db.close()

    return users


def fetch_data(subjectid: Optional[int] = None):
    db = get_db_connection()
    if db is None:
        raise HTTPException(status_code=500, detail="数据库连接失败")

    try:
        cursor = db.cursor(dictionary=True)
        if subjectid:
            query = "SELECT subjectid, rating FROM comments WHERE subjectid = %s"
            cursor.execute(query, (subjectid,))
        else:
            cursor.execute("SELECT subjectid, rating FROM comments")
        rows = cursor.fetchall()
        return rows
    finally:
        cursor.close()
        db.close()


def calculate_scores(data):
    # 定义豆瓣评分到分数的映射
    ratings_map = {
        "力荐": 10,
        "推荐": 9,
        "还行": 8,
        "较差": 7,
        "很差": 6
    }
    df = pd.DataFrame(data)
    # 根据映射将评分转换为分数
    df['rating_value'] = df['rating'].map(ratings_map)

    # 计算每个subjectid的星级分布
    result = df.groupby('subjectid')['rating_value'].value_counts().unstack(fill_value=0)
    result.columns = [str(int(col)) for col in result.columns]  # 列名更改为星级

    # 计算总分
    result['total_score'] = (result['10'] * 10 + result['9'] * 9 + result['8'] * 8 + result['7'] * 7 + result['6'] * 6) / (result['10'] + result['9'] + result['8'] + result['7'] + result['6'])
    
    # 定义总分到星级的映射
    def score_to_star(score):
        if score >= 9:
            return 5
        elif score >= 8:
            return 4
        elif score >= 7:
            return 3
        elif score >= 6:
            return 2
        else:
            return 1

    # 映射总分到星级
    result['star_rating'] = result['total_score'].apply(score_to_star)

    # 将星级按豆瓣格式整理
    star_distribution = result[['6', '7', '8', '9', '10']].rename(columns={'6': '1', '7': '2', '8': '3', '9': '4', '10': '5'})
    star_distribution['total_score'] = result['total_score']
    star_distribution['star_rating'] = result['star_rating']

    return star_distribution.reset_index().to_dict(orient='records')    


@app.get("/scores/")
async def get_scores(subjectid: Optional[int] = Query(None)):
    data = fetch_data(subjectid)
    scores = calculate_scores(data)
    return scores


if __name__ == '__main__':
    uvicorn.run('main:app')
    
    
    